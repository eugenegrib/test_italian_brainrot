// Figure.cs
// Скрипт, управляющий поведением отдельной фишки на игровом поле.
// Отвечает за визуал, физику, обработку кликов и воспроизведение звука первого касания.

using UnityEngine;
using System;
// using System.Collections.Generic; // Этот using не нужен, можно убрать для чистоты
#if UNITY_EDITOR
using UnityEditor; 
#endif

public class Figure : MonoBehaviour
{
    // Уникальный идентификатор этой фишки.
    [SerializeField] private FigureTypeID _figureID;
    public FigureTypeID FigureID => _figureID;

    // Компоненты физики, прикрепленные к корневому GameObject.
    private PolygonCollider2D _collider2D;
    private Rigidbody2D _rigidbody2D;

    [Header("Визуальные компоненты (назначить в редакторе)")]
    // SpriteRenderer'ы для слоев фишки (фон, внутренний цвет, животное).
    [SerializeField] private SpriteRenderer _backgroundShapeRenderer; 
    [SerializeField] private SpriteRenderer _coloredInnerShapeRenderer; 
    [SerializeField] private SpriteRenderer _animalRenderer; 

    [Header("Настройки перетаскивания/клика")]
    [SerializeField] private float _dragForce = 100f; 
    [SerializeField] private float _dragThreshold = 0.5f; 

    private Vector3 _mouseDownWorldPos; 
    private bool _isDragging = false;   

    private bool _hasPlayedCollisionSound = false; // Флаг: был ли уже звук столкновения
    [SerializeField] [Tooltip("Задержка в секундах, после которой фишка может начать издавать звук столкновения.")]
    private float _collisionSoundDelayAfterSpawn = 1.0f; // <-- НОВОЕ ПОЛЕ: Задержка для звука столкновения
    private float _collisionSoundActivationTime; // <-- НОВОЕ ПОЛЕ: Время, когда звук столкновения станет активен

    // Событие, которое срабатывает при "чистом" клике на фишку (без перетаскивания).
    public static event Action<Figure> OnFigureClicked;

    void Awake()
    {
        _collider2D = GetComponent<PolygonCollider2D>();
        _rigidbody2D = GetComponent<Rigidbody2D>();

        if (_collider2D == null) Debug.LogError("Figure: PolygonCollider2D не найден на корневом объекте!", this);
        if (_rigidbody2D == null) Debug.LogError("Figure: Rigidbody2D не найден на корневом объекте!", this);

        if (_backgroundShapeRenderer == null) Debug.LogWarning("Figure: Background Shape Renderer не назначен!", this);
        if (_coloredInnerShapeRenderer == null) Debug.LogWarning("Figure: Colored Inner Shape Renderer не назначен!", this);
        if (_animalRenderer == null) Debug.LogWarning("Figure: Animal Renderer не назначен!", this);
    }

    /// <summary>
    /// Вызывается после создания/получения из пула для сброса состояния фишки.
    /// </summary>
    public void Initialize()
    {
        ResetPhysicsState();
        _hasPlayedCollisionSound = false; 
        _collisionSoundActivationTime = Time.time + _collisionSoundDelayAfterSpawn; // <-- НОВОЕ: Задаем время активации звука
    }

    /// <summary>
    /// Этот метод вызывается ИСКЛЮЧИТЕЛЬНО в EDITOR-скрипте PoolPreCreator
    /// для начальной настройки визуалов и коллайдера префаба/инстанса в сцене.
    /// </summary>
    public void SetVisualsAndColliderInEditor(FigureTypeID id, FigureVisualsConfig visualsConfig)
    {
        _figureID = id;

        if (_backgroundShapeRenderer != null)
        {
            _backgroundShapeRenderer.sprite = visualsConfig.GetBackgroundShapeSprite(id.Shape);
            _backgroundShapeRenderer.color = Color.white; 
            _backgroundShapeRenderer.gameObject.layer = LayerMask.NameToLayer("Default");
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(_backgroundShapeRenderer.gameObject);
            #endif
        }
        else Debug.LogError($"Figure: Background Shape Renderer NULL для {id}. Не могу настроить визуал.", this);

        if (_coloredInnerShapeRenderer != null)
        {
            _coloredInnerShapeRenderer.sprite = visualsConfig.GetColoredInnerShapeSprite(id.Shape);
            _coloredInnerShapeRenderer.color = visualsConfig.GetShapeColor(id.ShapeColor);
            _coloredInnerShapeRenderer.gameObject.layer = LayerMask.NameToLayer("Default");
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(_coloredInnerShapeRenderer.gameObject);
            #endif
        }
        if (_animalRenderer != null)
        {
            _animalRenderer.sprite = visualsConfig.GetAnimalSprite(id.Animal);
            _animalRenderer.color = Color.white; 
            _animalRenderer.gameObject.layer = LayerMask.NameToLayer("Default");
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(_animalRenderer.gameObject);
            #endif
        }

        this.gameObject.layer = LayerMask.NameToLayer("Default"); 

        _collider2D = GetComponent<PolygonCollider2D>();
        if (_collider2D == null)
        {
            _collider2D = gameObject.AddComponent<PolygonCollider2D>();
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(_collider2D);
            #endif
            Debug.Log($"Figure: PolygonCollider2D добавлен для {id}.", this);
        }

        _rigidbody2D = GetComponent<Rigidbody2D>();
        if (_rigidbody2D == null)
        {
            _rigidbody2D = gameObject.AddComponent<Rigidbody2D>();
            _rigidbody2D.bodyType = RigidbodyType2D.Dynamic;
            _rigidbody2D.gravityScale = 1f;
            #if UNITY_EDITOR
            UnityEditor.EditorUtility.SetDirty(_rigidbody2D);
            #endif
            Debug.Log($"Figure: Rigidbody2D добавлен для {id}.", this);
        }

        if (_collider2D != null && _backgroundShapeRenderer.sprite != null)
        {
            Sprite spriteToUseForCollider = _backgroundShapeRenderer.sprite;
            System.Collections.Generic.List<Vector2> physicsShapeVertices = new System.Collections.Generic.List<Vector2>();

            if (spriteToUseForCollider.GetPhysicsShapeCount() > 0)
            {
                spriteToUseForCollider.GetPhysicsShape(0, physicsShapeVertices);
            }
            else
            {
                Debug.LogWarning($"Спрайт '{spriteToUseForCollider.name}' не имеет своей физ. формы. Используем вершины спрайта для коллайдера {id}.", spriteToUseForCollider);
                physicsShapeVertices.AddRange(spriteToUseForCollider.vertices);
            }

            if (physicsShapeVertices.Count > 0)
            {
                _collider2D.points = physicsShapeVertices.ToArray();
                #if UNITY_EDITOR
                UnityEditor.EditorUtility.SetDirty(_collider2D);
                #endif
            }
            else
            {
                Debug.LogWarning($"Figure: Не удалось получить вершины коллайдера для {spriteToUseForCollider.name} для {id}. Используем квадрат.", this);
                _collider2D.points = new Vector2[] { new Vector2(-0.5f, -0.5f), new Vector2(0.5f, -0.5f), new Vector2(0.5f, 0.5f), new Vector2(-0.5f, 0.5f) };
                #if UNITY_EDITOR
                UnityEditor.EditorUtility.SetDirty(_collider2D);
                #endif
            }
        }
        else
        {
            Debug.LogError($"Figure: Нет критически важных компонентов для {id}. Не могу настроить коллайдер. Проверьте назначения.", this);
        }

        Initialize();
    }

    /// <summary>
    /// Обработка нажатия кнопки мыши на коллайдере фишки.
    /// </summary>
    private void OnMouseDown()
    {
        if (GameManager.Instance == null || GameManager.Instance.CurrentGameState != GameManager.GameState.Playing)
        {
            return; 
        }

        if (_collider2D == null || !_collider2D.enabled || _rigidbody2D == null)
        {
            Debug.LogWarning("Figure: Компоненты отсутствуют или выключены, не могу обработать клик.", this);
            return;
        }

        _mouseDownWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        _mouseDownWorldPos.z = transform.position.z; 

        _isDragging = false;
        
        _rigidbody2D.linearVelocity = Vector2.zero;
        _rigidbody2D.angularVelocity = 0f;
    }

    /// <summary>
    /// Обработка перетаскивания кнопки мыши.
    /// </summary>
    private void OnMouseDrag()
    {
        if (GameManager.Instance == null || GameManager.Instance.CurrentGameState != GameManager.GameState.Playing) return;
        if (_collider2D == null || !_collider2D.enabled || _rigidbody2D == null || _rigidbody2D.isKinematic) return;

        Vector3 currentMouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        currentMouseWorldPos.z = transform.position.z; 

        if (!_isDragging && Vector3.Distance(_mouseDownWorldPos, currentMouseWorldPos) > _dragThreshold)
        {
            _isDragging = true;
        }
        
        if (_isDragging)
        {
            Vector3 forceDirection = (currentMouseWorldPos - (Vector3)_rigidbody2D.position);
            _rigidbody2D.AddForce(forceDirection * _dragForce * Time.fixedDeltaTime, ForceMode2D.Force);
        }
    }

    /// <summary>
    /// Обработка отпускания кнопки мыши.
    /// </summary>
    private void OnMouseUp()
    {
        if (GameManager.Instance == null || GameManager.Instance.CurrentGameState != GameManager.GameState.Playing) return;
        if (_collider2D == null || !_collider2D.enabled || _rigidbody2D == null) return;

        if (!_isDragging)
        {
            Debug.Log($"Figure: Кликнули по {FigureID.Animal}!");
            OnFigureClicked?.Invoke(this); 
        }
        _isDragging = false;
    }

    /// <summary>
    /// Обработка столкновений с другими физическими объектами.
    /// Звук проигрывается только при первом касании после инициализации и после задержки.
    /// </summary>
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Если звук уже проигран для этой фишки, или игра не в нужном состоянии, выходим.
        // Игнорируем столкновения для звука, пока не пройдет задержка после спавна.
        if (_hasPlayedCollisionSound || Time.time < _collisionSoundActivationTime ||
            GameManager.Instance == null || 
            (GameManager.Instance.CurrentGameState != GameManager.GameState.Playing && 
             GameManager.Instance.CurrentGameState != GameManager.GameState.Rerolling))
        {
            return; 
        }

        // Воспроизводим звук столкновения.
        GameManager.Instance.PlayCollisionSound();
        _hasPlayedCollisionSound = true; // Устанавливаем флаг, чтобы звук больше не проигрывался.
    }

    /// <summary>
    /// Переводит фишку в режим "панели действий" (отключает физику).
    /// </summary>
    public void SetInActionBarMode()
    {
        if (_rigidbody2D != null)
        {
            _rigidbody2D.isKinematic = true;
            _rigidbody2D.simulated = false;
        }
        if (_collider2D != null) _collider2D.enabled = false;
    }

    /// <summary>
    /// Сбрасывает физическое состояние фишки (для использования на игровом поле).
    /// </summary>
    public void ResetPhysicsState()
    {
        if (_rigidbody2D != null)
        {
            _rigidbody2D.isKinematic = false;
            _rigidbody2D.simulated = true;
            _rigidbody2D.linearVelocity = Vector2.zero;
            _rigidbody2D.angularVelocity = 0f;
        }
        if (_collider2D != null)
        {
            _collider2D.enabled = true;
        }
    }
}