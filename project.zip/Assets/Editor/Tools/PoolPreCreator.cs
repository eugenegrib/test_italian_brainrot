// PoolPreCreator.cs
// Инструмент для редактора Unity. Помогает заранее создать и настроить все нужные фишки для пула.

using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using UnityEditor.SceneManagement; // Для работы со сценой в редакторе

public class PoolPreCreator : EditorWindow
{
    private GameObject _baseFigurePrefab; // Основной префаб фишки (с компонентами Figure и физики)
    private FigureVisualsConfig _visualsConfig; // Конфиг с визуалами фишек
    private ObjectPoolManager _poolManager; // Ссылка на менеджер пула в сцене
    private string _poolParentObjectName = "FigurePool"; // Название родительского объекта для фишек в пуле
    [Tooltip("Сколько экземпляров каждого уникального типа фишки создать в пуле (например, 2 для 'в два раза больше').")]
    private int _poolSizeMultiplier = 2; // Множитель размера пула для каждого типа

    /// <summary>
    /// Добавляет пункт "Populate Unique Figure Pool" в меню "Tools/Game".
    /// </summary>
    [MenuItem("Tools/Game/Populate Unique Figure Pool")]
    public static void ShowWindow()
    {
        GetWindow<PoolPreCreator>("Populate Unique Figure Pool");
    }

    /// <summary>
    /// Рисует интерфейс окна редактора.
    /// </summary>
    private void OnGUI()
    {
        GUILayout.Label("Создать фишки для пула", EditorStyles.boldLabel);

        _baseFigurePrefab = (GameObject)EditorGUILayout.ObjectField("Базовый префаб фишки", _baseFigurePrefab, typeof(GameObject), false);
        _visualsConfig = (FigureVisualsConfig)EditorGUILayout.ObjectField("Конфиг визуалов", _visualsConfig, typeof(FigureVisualsConfig), false);
        _poolManager = (ObjectPoolManager)EditorGUILayout.ObjectField("Менеджер пула (на сцене)", _poolManager, typeof(ObjectPoolManager), true);
        _poolSizeMultiplier = EditorGUILayout.IntField("Множитель размера пула (на каждый тип)", _poolSizeMultiplier);

        if (GUILayout.Button("Создать пул (очистить и создать)"))
        {
            PopulatePool();
        }

        if (_baseFigurePrefab == null || _visualsConfig == null || _poolManager == null)
        {
            EditorGUILayout.HelpBox("Назначьте базовый префаб, конфиг визуалов и менеджер пула.", MessageType.Warning);
        }
    }

    /// <summary>
    /// Очищает существующий пул и создает новые экземпляры фишек для каждого уникального типа.
    /// </summary>
    private void PopulatePool()
    {
        if (_baseFigurePrefab == null || _visualsConfig == null || _poolManager == null)
        {
            Debug.LogError("Не могу создать пул: не назначены все нужные объекты.");
            return;
        }
        if (_baseFigurePrefab.GetComponent<Figure>() == null)
        {
            Debug.LogError("Базовый префаб фишки должен иметь скрипт 'Figure' на корневом объекте.", _baseFigurePrefab);
            return;
        }

        ClearExistingPoolObjects(); // Сначала чистим все, что было

        Transform poolParent = _poolManager.transform.Find(_poolParentObjectName);
        if (poolParent == null)
        {
            poolParent = new GameObject(_poolParentObjectName).transform;
            poolParent.SetParent(_poolManager.transform);
        }

        int totalCreatedCount = 0;
        AssetDatabase.StartAssetEditing(); // Начинаем быструю обработку ассетов

        ShapeType[] shapeTypes = (ShapeType[])Enum.GetValues(typeof(ShapeType));
        ShapeColorType[] shapeColorTypes = (ShapeColorType[])Enum.GetValues(typeof(ShapeColorType));
        AnimalType[] animalTypes = (AnimalType[])Enum.GetValues(typeof(AnimalType));

        foreach (ShapeType shape in shapeTypes)
        {
            // Пропускаем, если для этой формы нет спрайтов.
            if (_visualsConfig.GetBackgroundShapeSprite(shape) == null ||
                _visualsConfig.GetColoredInnerShapeSprite(shape) == null)
            {
                Debug.LogWarning($"Пропускаем форму {shape}: нет спрайтов фона или внутренней части в конфиге.");
                continue;
            }

            foreach (ShapeColorType shapeColor in shapeColorTypes)
            {
                // Пропускаем, если нет цвета.
                if (_visualsConfig.GetShapeColor(shapeColor) == Color.magenta) 
                {
                    Debug.LogWarning($"Пропускаем цвет {shapeColor}: нет цвета в конфиге.");
                    continue;
                }

                foreach (AnimalType animal in animalTypes)
                {
                    // Пропускаем, если нет спрайта животного.
                    if (_visualsConfig.GetAnimalSprite(animal) == null)
                    {
                        Debug.LogWarning($"Пропускаем животное {animal}: нет спрайта животного в конфиге.");
                        continue;
                    }

                    for (int i = 0; i < _poolSizeMultiplier; i++)
                    {
                        GameObject instance = (GameObject)PrefabUtility.InstantiatePrefab(_baseFigurePrefab, poolParent);

                        Figure figureComponent = instance.GetComponent<Figure>();
                        
                        // Получаем ссылки на рендереры дочерних объектов.
                        Transform backgroundShapeTransform = instance.transform.Find("BackgroundShape");
                        SpriteRenderer backgroundShapeRenderer = backgroundShapeTransform?.GetComponent<SpriteRenderer>();

                        Transform coloredInnerShapeTransform = backgroundShapeTransform?.Find("ColoredInnerShape");
                        SpriteRenderer coloredInnerShapeRenderer = coloredInnerShapeTransform?.GetComponent<SpriteRenderer>();

                        Transform animalTransform = backgroundShapeTransform?.Find("Animal");
                        SpriteRenderer animalRenderer = animalTransform?.GetComponent<SpriteRenderer>();
                        
                        // Проверяем, что все компоненты есть.
                        if (figureComponent == null || backgroundShapeRenderer == null || coloredInnerShapeRenderer == null || animalRenderer == null)
                        {
                            Debug.LogError($"Базовый префаб фишки ({_baseFigurePrefab.name}) неполный. Проверьте его структуру. Фишка не создана.");
                            DestroyImmediate(instance); 
                            AssetDatabase.StopAssetEditing(); 
                            return; 
                        }

                        // Назначаем ID фишке.
                        FigureTypeID currentFigureID = new FigureTypeID(shape, shapeColor, animal);
                        SerializedObject so = new SerializedObject(figureComponent);
                        SerializedProperty figureIDProp = so.FindProperty("_figureID");
                        figureIDProp.FindPropertyRelative("Shape").enumValueIndex = (int)currentFigureID.Shape;
                        figureIDProp.FindPropertyRelative("ShapeColor").enumValueIndex = (int)currentFigureID.ShapeColor;
                        figureIDProp.FindPropertyRelative("Animal").enumValueIndex = (int)currentFigureID.Animal;
                        so.ApplyModifiedProperties(); 

                        // Настраиваем визуал и коллайдер фишки.
                        figureComponent.SetVisualsAndColliderInEditor(currentFigureID, _visualsConfig);
                        EditorUtility.SetDirty(figureComponent); 

                        instance.SetActive(false); // Деактивируем фишку
                        _poolManager.AddPreCreatedFigure(figureComponent); // Добавляем в список менеджера пула

                        totalCreatedCount++;
                    }
                }
            }
        }

        AssetDatabase.StopAssetEditing(); // Заканчиваем быструю обработку
        EditorUtility.SetDirty(_poolManager); 
        AssetDatabase.SaveAssets(); // Сохраняем ассеты
        
        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene()); // Помечаем сцену как измененную
        EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene()); // Сохраняем сцену
        AssetDatabase.Refresh(); // Обновляем базу ассетов

        Debug.Log($"Создано {totalCreatedCount} уникальных фишек и назначено менеджеру пула. НЕ ЗАБУДЬТЕ СОХРАНИТЬ СЦЕНУ!");
        EditorUtility.DisplayDialog("Пул создан", $"Создано {totalCreatedCount} уникальных фишек. Не забудьте сохранить сцену!", "ОК");
    }

    /// <summary>
    /// Очищает все существующие объекты пула на сцене.
    /// </summary>
    private void ClearExistingPoolObjects()
    {
        if (_poolManager == null) return;

        Transform poolParent = _poolManager.transform.Find(_poolParentObjectName);
        if (poolParent != null)
        {
            List<GameObject> childrenToDestroy = new List<GameObject>();
            foreach (Transform child in poolParent)
            {
                childrenToDestroy.Add(child.gameObject);
            }
            foreach (GameObject go in childrenToDestroy)
            {
                DestroyImmediate(go); // Удаляем объекты сразу
            }
            DestroyImmediate(poolParent.gameObject); // Удаляем родительский объект пула
        }
        _poolManager.ClearPreCreatedFiguresList(); // Очищаем список в менеджере пула
        EditorUtility.SetDirty(_poolManager);
        AssetDatabase.SaveAssets();
    }
}