// FigureEnums.cs
// Перечисления для разных характеристик фишек: форма, цвет и животное.

public enum ShapeType
{
    Circle,
    Square,
    Triangle,
    RoundedSquare
}

public enum ShapeColorType
{
    Blue,
    Green,
    Yellow
}

public enum AnimalType
{
    Bananini,
    Crocodilo,
    Tralala,
    Capuchina
}