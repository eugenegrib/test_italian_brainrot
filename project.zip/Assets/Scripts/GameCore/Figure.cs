
using UnityEngine;
using System;
using System.Collections.Generic;
#if UNITY_EDITOR
using UnityEditor; 
#endif

public class Figure : MonoBehaviour
{
    // Уникальный идентификатор этой фигурки, состоящий из перечислений.
    [SerializeField] private FigureTypeID _figureID;
    public FigureTypeID FigureID => _figureID;

    // --- КОМПОНЕНТЫ НА ЭТОМ ЖЕ GameObject (Figure) ---
    private PolygonCollider2D _collider2D; // Теперь на Figure
    private Rigidbody2D _rigidbody2D;     // Теперь на Figure
    // --- КОНЕЦ КОМПОНЕНТОВ НА Figure ---

    [Header("Visual Components Renderers (Set in Editor)")]
    // Ссылки на SpriteRenderer'ы (все еще на дочерних объектах).
    [SerializeField] private SpriteRenderer _backgroundShapeRenderer; // На дочернем "BackgroundShape"
    [SerializeField] private SpriteRenderer _coloredInnerShapeRenderer; // На дочернем "ColoredInnerShape"
    [SerializeField] private SpriteRenderer _animalRenderer; // На дочернем "Animal"


    [Header("Drag/Click Settings")]
    [SerializeField] private float _dragForce = 100f; 
    [SerializeField] private float _dragThreshold = 0.5f; 

    private Vector3 _mouseDownWorldPos; 
    private bool _isDragging = false;   

    // НОВЫЕ ПОЛЯ: Настройки для звука столкновения
    [Header("Collision Sound Settings")]
    [SerializeField] private float _minCollisionVelocityForSound = 0.5f; // Минимальная относительная скорость для воспроизведения звука
    [SerializeField] private float _collisionSoundCooldown = 0.1f; // Кульдаун между воспроизведением звуков столкновения для этой фигуры
    private float _lastCollisionSoundTime = -Mathf.Infinity; // Время последнего воспроизведения звука столкновения

    public static event Action<Figure> OnFigureClicked;

    private void Awake()
    {
        _collider2D = GetComponent<PolygonCollider2D>();
        _rigidbody2D = GetComponent<Rigidbody2D>();

        if (_collider2D == null) Debug.LogError("Figure (Awake): PolygonCollider2D not found on ROOT Figure GameObject!", this);
        if (_rigidbody2D == null) Debug.LogError("Figure (Awake): Rigidbody2D not found on ROOT Figure GameObject!", this);

        if (_backgroundShapeRenderer == null) Debug.LogWarning("Figure (Awake): Background Shape Renderer is not assigned in prefab! Please drag the SpriteRenderer from 'BackgroundShape' child here.", this);
        if (_coloredInnerShapeRenderer == null) Debug.LogWarning("Figure (Awake): Colored Inner Shape Renderer is not assigned in prefab! Please drag the SpriteRenderer from 'ColoredInnerShape' grandchild here.", this);
        if (_animalRenderer == null) Debug.LogWarning("Figure (Awake): Animal Renderer is not assigned in prefab! Please drag the SpriteRenderer from 'Animal' grandchild here.", this);
    }

    public void Initialize()
    {
        ResetPhysicsState();
        _lastCollisionSoundTime = -Mathf.Infinity; // Сбрасываем кульдаун при инициализации
    }

    public void SetVisualsAndColliderInEditor(FigureTypeID id, FigureVisualsConfig visualsConfig)
    {
        _figureID = id; 

        if (_backgroundShapeRenderer == null)
        {
            Debug.LogError($"Figure: Background Shape Renderer is NULL for {id}. Cannot set up visuals. Ensure 'BackgroundShape' child object and its SpriteRenderer are set up in prefab and _backgroundShapeRenderer is assigned in Figure script.", this);
            return;
        }

        _backgroundShapeRenderer.sprite = visualsConfig.GetBackgroundShapeSprite(id.Shape);
        Color c_bg = Color.white; c_bg.a = 1f; _backgroundShapeRenderer.color = c_bg;
        _backgroundShapeRenderer.gameObject.layer = LayerMask.NameToLayer("Default");
        #if UNITY_EDITOR
        EditorUtility.SetDirty(_backgroundShapeRenderer.gameObject);
        #endif

        if (_coloredInnerShapeRenderer != null)
        {
            _coloredInnerShapeRenderer.sprite = visualsConfig.GetColoredInnerShapeSprite(id.Shape);
            Color c_inner = visualsConfig.GetShapeColor(id.ShapeColor);
            c_inner.a = 1f; _coloredInnerShapeRenderer.color = c_inner;
            _coloredInnerShapeRenderer.gameObject.layer = LayerMask.NameToLayer("Default");
            #if UNITY_EDITOR
            EditorUtility.SetDirty(_coloredInnerShapeRenderer.gameObject);
            #endif
        }
        if (_animalRenderer != null)
        {
            _animalRenderer.sprite = visualsConfig.GetAnimalSprite(id.Animal);
            Color c_animal = Color.white; c_animal.a = 1f; _animalRenderer.color = c_animal;
            _animalRenderer.gameObject.layer = LayerMask.NameToLayer("Default");
            #if UNITY_EDITOR
            EditorUtility.SetDirty(_animalRenderer.gameObject);
            #endif
        }

        this.gameObject.layer = LayerMask.NameToLayer("Default"); 

        _collider2D = GetComponent<PolygonCollider2D>();
        if (_collider2D == null)
        {
            _collider2D = gameObject.AddComponent<PolygonCollider2D>();
            #if UNITY_EDITOR
            EditorUtility.SetDirty(_collider2D);
            #endif
            Debug.Log($"Figure (SetVisuals): PolygonCollider2D was missing on ROOT Figure and was added programmatically for {id}.", this);
        }

        _rigidbody2D = GetComponent<Rigidbody2D>();
        if (_rigidbody2D == null)
        {
            _rigidbody2D = gameObject.AddComponent<Rigidbody2D>();
            _rigidbody2D.bodyType = RigidbodyType2D.Dynamic;
            _rigidbody2D.gravityScale = 1f;
            #if UNITY_EDITOR
            EditorUtility.SetDirty(_rigidbody2D);
            #endif
            Debug.Log($"Figure (SetVisuals): Rigidbody2D was missing on ROOT Figure and was added programmatically for {id}.", this);
        }

        if (_collider2D != null && _backgroundShapeRenderer.sprite != null)
        {
            Sprite spriteToUseForCollider = _backgroundShapeRenderer.sprite;
            List<Vector2> physicsShapeVertices = new List<Vector2>();

            if (spriteToUseForCollider.GetPhysicsShapeCount() > 0)
            {
                spriteToUseForCollider.GetPhysicsShape(0, physicsShapeVertices);
            }
            else
            {
                Debug.LogWarning($"Sprite {spriteToUseForCollider.name} has no custom physics shape. Using sprite.vertices for collider for {id}. Consider defining a custom physics shape in Sprite Editor.", spriteToUseForCollider);
                physicsShapeVertices.AddRange(spriteToUseForCollider.vertices);
            }

            if (physicsShapeVertices.Count > 0)
            {
                _collider2D.points = physicsShapeVertices.ToArray();
                #if UNITY_EDITOR
                EditorUtility.SetDirty(_collider2D);
                #endif
            }
            else
            {
                Debug.LogWarning($"Figure: Could not get valid collider vertices for {spriteToUseForCollider.name} for {id}. Using default square.", this);
                _collider2D.points = new Vector2[] { new Vector2(-0.5f, -0.5f), new Vector2(0.5f, -0.5f), new Vector2(0.5f, 0.5f), new Vector2(-0.5f, 0.5f) };
                #if UNITY_EDITOR
                EditorUtility.SetDirty(_collider2D);
                #endif
            }
        }
        else
        {
            string missingDetails = "";
            if (_collider2D == null) missingDetails += "PolygonCollider2D (on Figure) is null; ";
            if (_backgroundShapeRenderer.sprite == null) missingDetails += "BackgroundShapeRenderer.sprite is null; ";

            Debug.LogError($"Figure: Critical components or sprites missing for FigureTypeID {id}. Cannot set collider points. Details: {missingDetails} Ensure 'BackgroundShape' child object and its SpriteRenderer are set up, and references are assigned in Figure script.", this);
        }

        Initialize();
    }

    private void OnMouseDown()
    {
        if (GameManager.Instance == null || GameManager.Instance.CurrentGameState != GameManager.GameState.Playing)
        {
            Debug.LogWarning($"Figure (OnMouseDown): Click ignored. GameManager is null or game state is {GameManager.Instance?.CurrentGameState.ToString() ?? "N/A"}.");
            return; 
        }

        if (_collider2D == null || !_collider2D.enabled || _rigidbody2D == null)
        {
            Debug.LogWarning("Figure (OnMouseDown): Figure's components missing or disabled, cannot process click.", this);
            return;
        }
        
        Debug.Log($"OnMouseDown вызван на Figure! Объект: {gameObject.name}, Слой: {LayerMask.LayerToName(gameObject.layer)}", this);

        _mouseDownWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        _mouseDownWorldPos.z = transform.position.z; 

        _isDragging = false;
        
        _rigidbody2D.linearVelocity = Vector2.zero;
        _rigidbody2D.angularVelocity = 0f;
    }

    private void OnMouseDrag()
    {
        if (GameManager.Instance == null || GameManager.Instance.CurrentGameState != GameManager.GameState.Playing) return;
        if (_collider2D == null || !_collider2D.enabled || _rigidbody2D == null || _rigidbody2D.isKinematic) return;

        Vector3 currentMouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        currentMouseWorldPos.z = transform.position.z; 

        if (!_isDragging && Vector3.Distance(_mouseDownWorldPos, currentMouseWorldPos) > _dragThreshold)
        {
            _isDragging = true;
        }
        
        if (_isDragging)
        {
            Vector3 forceDirection = (currentMouseWorldPos - (Vector3)_rigidbody2D.position);
            _rigidbody2D.AddForce(forceDirection * _dragForce * Time.fixedDeltaTime, ForceMode2D.Force);
        }
    }

    private void OnMouseUp()
    {
        if (GameManager.Instance == null || GameManager.Instance.CurrentGameState != GameManager.GameState.Playing) return;
        if (_collider2D == null || !_collider2D.enabled || _rigidbody2D == null) return;

        if (!_isDragging)
        {
            Debug.Log($"Pure click detected on Figure (FigureID: {_figureID.Animal})!");
            OnFigureClicked?.Invoke(this); 
        }
        _isDragging = false;
    }



    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (GameManager.Instance == null || 
            (GameManager.Instance.CurrentGameState != GameManager.GameState.Playing && 
             GameManager.Instance.CurrentGameState != GameManager.GameState.Rerolling))
        {
            return; 
        }

        // Проверяем кульдаун
        if (Time.time < _lastCollisionSoundTime + _collisionSoundCooldown)
        {
            return;
        }

        // Проверяем силу столкновения
        if (collision.relativeVelocity.magnitude > _minCollisionVelocityForSound)
        {
            GameManager.Instance.PlayCollisionSound();
            _lastCollisionSoundTime = Time.time; // Обновляем время последнего звука
        }
    }

    public void SetInActionBarMode()
    {
        if (_rigidbody2D != null)
        {
            _rigidbody2D.isKinematic = true;
            _rigidbody2D.simulated = false;
        }
        if (_collider2D != null) _collider2D.enabled = false;
    }

    public void ResetPhysicsState()
    {
        if (_rigidbody2D != null)
        {
            _rigidbody2D.isKinematic = false;
            _rigidbody2D.simulated = true;
            _rigidbody2D.linearVelocity = Vector2.zero;
            _rigidbody2D.angularVelocity = 0f;
        }
        if (_collider2D != null)
        {
            _collider2D.enabled = true;
        }
    }
}