// FigureVisualsConfig.cs
// Хранит ссылки на все спрайты и цвета,
// используемые для визуального представления фигурок.

using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "FigureVisualsConfig", menuName = "Game/Figure Visuals Config")]
public class FigureVisualsConfig : ScriptableObject
{
    [Serializable]
    public struct BackgroundShapeSpriteEntry
    {
        public ShapeType type;
        public Sprite sprite;
        // public Vector2[] colliderVertices; // <-- УДАЛИТЬ ЭТУ СТРОКУ!
    }

    [Serializable]
    public struct ColoredInnerShapeSpriteEntry
    {
        public ShapeType type;
        public Sprite sprite;
    }

    [Serializable]
    public struct AnimalSpriteEntry
    {
        public AnimalType type;
        public Sprite sprite;
    }

    [Serializable]
    public struct ShapeColorEntry
    {
        public ShapeColorType type;
        public Color color;
    }

    [Header("Background Shape Sprites")]
    public List<BackgroundShapeSpriteEntry> backgroundShapeSprites;

    [Header("Colored Inner Shape Sprites")]
    public List<ColoredInnerShapeSpriteEntry> coloredInnerShapeSprites;

    [Header("Animal Sprites")]
    public List<AnimalSpriteEntry> animalSprites;

    [Header("Shape Colors")]
    public List<ShapeColorEntry> shapeColors;

    // Вспомогательные методы для получения спрайтов/цветов/данных по типу.

    // Теперь возвращает только спрайт
    public Sprite GetBackgroundShapeSprite(ShapeType type)
    {
        foreach (var entry in backgroundShapeSprites)
        {
            if (entry.type == type) return entry.sprite;
        }
        Debug.LogError($"Background shape sprite not found for type: {type}");
        return null;
    }

    // Этот метод теперь не нужен, так как colliderVertices удалены.
    // Если он где-то используется, его нужно будет пересмотреть.
    // public BackgroundShapeSpriteEntry GetBackgroundShapeEntry(ShapeType type)
    // {
    //     foreach (var entry in backgroundShapeSprites)
    //     {
    //         if (entry.type == type) return entry;
    //     }
    //     Debug.LogError($"Background shape entry not found for type: {type}");
    //     return default;
    // }

    public Sprite GetColoredInnerShapeSprite(ShapeType shapeType)
    {
        foreach (var entry in coloredInnerShapeSprites)
        {
            if (entry.type == shapeType) return entry.sprite;
        }
        Debug.LogError($"Colored inner shape sprite not found for type: {shapeType}");
        return null;
    }

    public Sprite GetAnimalSprite(AnimalType type)
    {
        foreach (var entry in animalSprites)
        {
            if (entry.type == type) return entry.sprite;
        }
        Debug.LogError($"Animal sprite not found for type: {type}");
        return null;
    }

    public Color GetShapeColor(ShapeColorType type)
    {
        foreach (var entry in shapeColors)
        {
            if (entry.type == type) return entry.color;
        }
        Debug.LogError($"Shape color not found for type: {type}");
        return Color.magenta;
    }
}