Fantasy SFX for Particle Distort Texture effect library package is a free gift which includes all fantasy sound effects and bgm used in the demo video for the particle effects of our Particle Distort Texture (shader and particle library) package which is being sold separately under the "Particle Systems" category. If you have already purchased the visual effect package, the sound effect in this audio package can be used straightaway for the particle effect prefab of namesake. But even without the said graphic package you can still freely use this audio package commerically.

This package includes source sound effects (file name begins with "msfx_" prefix) before mixing together and reverb being applied so you can mix and match in case you are not satisfied with the premixed sound (file name begins with "sfx_" prefix) or you just want to use one of the ingredient sound for whatever reason.

Particle Distort Texture package:
https://www.assetstore.unity3d.com/#!/content/41532

Youtube demo video:
